<h2>How to use uniMail</h2>

<ol>
	<li>Include jQuery;</li>
	<li>Include Ajax code from script.js;</li>
	<li>Change Ajax selector in you JS;</li>
	<li>Create HTML form with you form class;</li>
	<li>Create HTML Hidden Required Fields with you values;</li>
	<li>Change path to mail.php in you JS.</li>
	<li>Done!</li>
</ol>